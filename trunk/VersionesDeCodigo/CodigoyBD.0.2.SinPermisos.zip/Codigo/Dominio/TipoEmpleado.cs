﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Logica
{
    public abstract class TipoEmpleado
    {
        protected string NombreTipo;
        protected string Descripcion;
        protected int CantidadHorasComunes;

    }
}
