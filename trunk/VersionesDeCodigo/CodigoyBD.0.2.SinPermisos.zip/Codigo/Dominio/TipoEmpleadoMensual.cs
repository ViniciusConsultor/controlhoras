﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Logica
{
    class TipoEmpleadoMensual : TipoEmpleado
    {
        private Boolean fulltime;
        private Boolean CobraHorasExtras;

    }
}
