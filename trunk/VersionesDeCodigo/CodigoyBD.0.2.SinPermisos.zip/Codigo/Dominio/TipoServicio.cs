﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Logica
{
    class TipoServicio
    {
        int idTipoServicio;
        string NombreServicio;
    }
}
