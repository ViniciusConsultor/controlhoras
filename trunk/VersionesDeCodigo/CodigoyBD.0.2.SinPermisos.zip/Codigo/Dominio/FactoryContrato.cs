﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Logica
{
    static class FactoryContrato
    {
        static Contrato obtenerContrato(int idServicio)
        {

            return null;
        }
    }
}
