﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Logica
{
    // ME PARECE KE HAY KE BORRAR ESTA CLASE
    class ContratoPrecioHoraHombre
    {
        TipoEmpleado TipoDeEmpleado;
        float CostoHoraHombreSinIVA;
        Contrato ContratoRef;

    }
}
