﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Utilidades
{
    static class DataDia
    {
        public enum Dia { DOMINGO, LUNES, MARTES, MIERCOLES, JUEVES, VIERNES }

    }
}
