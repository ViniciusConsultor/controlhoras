﻿namespace ControlHoras
{
    partial class EscalafonForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EscalafonForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.GraficosPL = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.ConLBL = new System.Windows.Forms.Label();
            this.CubiertoLBL = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.cubiertoTB = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.PosteriorBTN = new System.Windows.Forms.Button();
            this.AnteriorBTN = new System.Windows.Forms.Button();
            this.VerContratoBTN = new System.Windows.Forms.Button();
            this.mtServicio = new System.Windows.Forms.MaskedTextBox();
            this.mtCliente = new System.Windows.Forms.MaskedTextBox();
            this.txtServicio = new System.Windows.Forms.TextBox();
            this.txtCliente = new System.Windows.Forms.TextBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.GuardarBTN = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.btnBuscarClientes = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.btnVerEscalafonFuncionario = new System.Windows.Forms.ToolStripButton();
            this.btnCancelar = new System.Windows.Forms.ToolStripButton();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.btnEliminarLineaEscalafon = new System.Windows.Forms.Button();
            this.btnAgregarLineaEscalafon = new System.Windows.Forms.Button();
            this.dgEscalafon = new ControlHoras.DataGridTAB();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvHsPorCubrir = new System.Windows.Forms.DataGridView();
            this.HsACubrirLunes = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HsACubrirMartes = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HsACubrirMiercoles = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HsACubrirJueves = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HsACubrirViernes = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HsACubrirSabado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HsACubrirDomingo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EscalafonCMS = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.copiarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pegarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.marcarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enOtroServicioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.descansoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.licenciaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.GraficosPL.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgEscalafon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHsPorCubrir)).BeginInit();
            this.EscalafonCMS.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.GraficosPL);
            this.splitContainer1.Panel1.Controls.Add(this.PosteriorBTN);
            this.splitContainer1.Panel1.Controls.Add(this.AnteriorBTN);
            this.splitContainer1.Panel1.Controls.Add(this.VerContratoBTN);
            this.splitContainer1.Panel1.Controls.Add(this.mtServicio);
            this.splitContainer1.Panel1.Controls.Add(this.mtCliente);
            this.splitContainer1.Panel1.Controls.Add(this.txtServicio);
            this.splitContainer1.Panel1.Controls.Add(this.txtCliente);
            this.splitContainer1.Panel1.Controls.Add(this.toolStrip1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Panel2.Enabled = false;
            this.splitContainer1.Size = new System.Drawing.Size(959, 484);
            this.splitContainer1.SplitterDistance = 103;
            this.splitContainer1.TabIndex = 1;
            // 
            // GraficosPL
            // 
            this.GraficosPL.Controls.Add(this.label9);
            this.GraficosPL.Controls.Add(this.label7);
            this.GraficosPL.Controls.Add(this.label5);
            this.GraficosPL.Controls.Add(this.ConLBL);
            this.GraficosPL.Controls.Add(this.CubiertoLBL);
            this.GraficosPL.Controls.Add(this.label10);
            this.GraficosPL.Controls.Add(this.label8);
            this.GraficosPL.Controls.Add(this.cubiertoTB);
            this.GraficosPL.Controls.Add(this.label6);
            this.GraficosPL.Location = new System.Drawing.Point(670, 35);
            this.GraficosPL.Name = "GraficosPL";
            this.GraficosPL.Size = new System.Drawing.Size(280, 65);
            this.GraficosPL.TabIndex = 19;
            this.GraficosPL.Visible = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(46, 45);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(100, 13);
            this.label9.TabIndex = 27;
            this.label9.Text = "Horario en Conflicto";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(46, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 13);
            this.label7.TabIndex = 23;
            this.label7.Text = "Empleados";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(46, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 13);
            this.label5.TabIndex = 25;
            this.label5.Text = "Horario Normal";
            // 
            // ConLBL
            // 
            this.ConLBL.AutoSize = true;
            this.ConLBL.Location = new System.Drawing.Point(191, 32);
            this.ConLBL.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ConLBL.Name = "ConLBL";
            this.ConLBL.Size = new System.Drawing.Size(47, 13);
            this.ConLBL.TabIndex = 21;
            this.ConLBL.Text = "Contarto";
            // 
            // CubiertoLBL
            // 
            this.CubiertoLBL.AutoSize = true;
            this.CubiertoLBL.Location = new System.Drawing.Point(180, 45);
            this.CubiertoLBL.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.CubiertoLBL.Name = "CubiertoLBL";
            this.CubiertoLBL.Size = new System.Drawing.Size(81, 13);
            this.CubiertoLBL.TabIndex = 20;
            this.CubiertoLBL.Text = "NO CUBIERTO";
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(29, 45);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(11, 13);
            this.label10.TabIndex = 26;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label8.Location = new System.Drawing.Point(29, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(11, 13);
            this.label8.TabIndex = 22;
            // 
            // cubiertoTB
            // 
            this.cubiertoTB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.cubiertoTB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cubiertoTB.Location = new System.Drawing.Point(197, 9);
            this.cubiertoTB.Margin = new System.Windows.Forms.Padding(2);
            this.cubiertoTB.Name = "cubiertoTB";
            this.cubiertoTB.ReadOnly = true;
            this.cubiertoTB.Size = new System.Drawing.Size(34, 20);
            this.cubiertoTB.TabIndex = 19;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label6.Location = new System.Drawing.Point(29, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(11, 13);
            this.label6.TabIndex = 24;
            // 
            // PosteriorBTN
            // 
            this.PosteriorBTN.AutoSize = true;
            this.PosteriorBTN.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.PosteriorBTN.Location = new System.Drawing.Point(460, 66);
            this.PosteriorBTN.Name = "PosteriorBTN";
            this.PosteriorBTN.Size = new System.Drawing.Size(29, 23);
            this.PosteriorBTN.TabIndex = 18;
            this.PosteriorBTN.Text = ">>";
            this.PosteriorBTN.UseVisualStyleBackColor = true;
            this.PosteriorBTN.Visible = false;
            this.PosteriorBTN.Click += new System.EventHandler(this.PosteriorBTN_Click);
            // 
            // AnteriorBTN
            // 
            this.AnteriorBTN.AutoSize = true;
            this.AnteriorBTN.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.AnteriorBTN.Location = new System.Drawing.Point(429, 66);
            this.AnteriorBTN.Name = "AnteriorBTN";
            this.AnteriorBTN.Size = new System.Drawing.Size(29, 23);
            this.AnteriorBTN.TabIndex = 17;
            this.AnteriorBTN.Text = "<<";
            this.AnteriorBTN.UseVisualStyleBackColor = true;
            this.AnteriorBTN.Visible = false;
            this.AnteriorBTN.Click += new System.EventHandler(this.AnteriorBTN_Click);
            // 
            // VerContratoBTN
            // 
            this.VerContratoBTN.AutoSize = true;
            this.VerContratoBTN.Enabled = false;
            this.VerContratoBTN.Location = new System.Drawing.Point(550, 65);
            this.VerContratoBTN.Margin = new System.Windows.Forms.Padding(2);
            this.VerContratoBTN.Name = "VerContratoBTN";
            this.VerContratoBTN.Size = new System.Drawing.Size(76, 23);
            this.VerContratoBTN.TabIndex = 4;
            this.VerContratoBTN.Text = "Ver Contrato";
            this.VerContratoBTN.UseVisualStyleBackColor = true;
            this.VerContratoBTN.Click += new System.EventHandler(this.VerContratoBTN_Click);
            // 
            // mtServicio
            // 
            this.mtServicio.BackColor = System.Drawing.SystemColors.Window;
            this.mtServicio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mtServicio.Location = new System.Drawing.Point(12, 65);
            this.mtServicio.Mask = "9990";
            this.mtServicio.Name = "mtServicio";
            this.mtServicio.ReadOnly = true;
            this.mtServicio.Size = new System.Drawing.Size(44, 22);
            this.mtServicio.TabIndex = 14;
            this.mtServicio.KeyDown += new System.Windows.Forms.KeyEventHandler(this.mtServicio_KeyDown);
            // 
            // mtCliente
            // 
            this.mtCliente.AllowPromptAsInput = false;
            this.mtCliente.BackColor = System.Drawing.SystemColors.Window;
            this.mtCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mtCliente.Location = new System.Drawing.Point(12, 38);
            this.mtCliente.Mask = "0000";
            this.mtCliente.Name = "mtCliente";
            this.mtCliente.Size = new System.Drawing.Size(44, 22);
            this.mtCliente.TabIndex = 13;
            this.mtCliente.KeyDown += new System.Windows.Forms.KeyEventHandler(this.mtCliente_KeyDown);
            // 
            // txtServicio
            // 
            this.txtServicio.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtServicio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtServicio.Location = new System.Drawing.Point(62, 66);
            this.txtServicio.Name = "txtServicio";
            this.txtServicio.ReadOnly = true;
            this.txtServicio.Size = new System.Drawing.Size(362, 22);
            this.txtServicio.TabIndex = 15;
            this.txtServicio.TabStop = false;
            // 
            // txtCliente
            // 
            this.txtCliente.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCliente.Location = new System.Drawing.Point(62, 39);
            this.txtCliente.Name = "txtCliente";
            this.txtCliente.ReadOnly = true;
            this.txtCliente.Size = new System.Drawing.Size(362, 22);
            this.txtCliente.TabIndex = 16;
            this.txtCliente.TabStop = false;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.GuardarBTN,
            this.toolStripSeparator2,
            this.btnBuscarClientes,
            this.toolStripSeparator3,
            this.btnVerEscalafonFuncionario,
            this.btnCancelar});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(959, 36);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // GuardarBTN
            // 
            this.GuardarBTN.Enabled = false;
            this.GuardarBTN.Image = global::ControlHoras.Properties.Resources.filesave;
            this.GuardarBTN.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.GuardarBTN.Name = "GuardarBTN";
            this.GuardarBTN.Size = new System.Drawing.Size(50, 33);
            this.GuardarBTN.Text = "Guardar";
            this.GuardarBTN.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.GuardarBTN.Click += new System.EventHandler(this.GuardarBTN_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 36);
            // 
            // btnBuscarClientes
            // 
            this.btnBuscarClientes.Image = global::ControlHoras.Imagenes.ClientsSearch42x42;
            this.btnBuscarClientes.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnBuscarClientes.Name = "btnBuscarClientes";
            this.btnBuscarClientes.Size = new System.Drawing.Size(79, 33);
            this.btnBuscarClientes.Text = "Buscar Cliente";
            this.btnBuscarClientes.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnBuscarClientes.Click += new System.EventHandler(this.btnBuscarClientes_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 36);
            // 
            // btnVerEscalafonFuncionario
            // 
            this.btnVerEscalafonFuncionario.Image = ((System.Drawing.Image)(resources.GetObject("btnVerEscalafonFuncionario.Image")));
            this.btnVerEscalafonFuncionario.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnVerEscalafonFuncionario.Name = "btnVerEscalafonFuncionario";
            this.btnVerEscalafonFuncionario.Size = new System.Drawing.Size(115, 33);
            this.btnVerEscalafonFuncionario.Text = "Escalafon Funcionario";
            this.btnVerEscalafonFuncionario.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnVerEscalafonFuncionario.Click += new System.EventHandler(this.btnVerEscalafonFuncionario_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnCancelar.Image = global::ControlHoras.Imagenes.button_cancel;
            this.btnCancelar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(53, 33);
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCancelar.ToolTipText = "Limpia la pantalla";
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.btnEliminarLineaEscalafon);
            this.splitContainer2.Panel1.Controls.Add(this.btnAgregarLineaEscalafon);
            this.splitContainer2.Panel1.Controls.Add(this.dgEscalafon);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.label3);
            this.splitContainer2.Panel2.Controls.Add(this.label4);
            this.splitContainer2.Panel2.Controls.Add(this.label2);
            this.splitContainer2.Panel2.Controls.Add(this.label1);
            this.splitContainer2.Panel2.Controls.Add(this.dgvHsPorCubrir);
            this.splitContainer2.Size = new System.Drawing.Size(959, 377);
            this.splitContainer2.SplitterDistance = 297;
            this.splitContainer2.TabIndex = 0;
            // 
            // btnEliminarLineaEscalafon
            // 
            this.btnEliminarLineaEscalafon.BackColor = System.Drawing.Color.LightYellow;
            this.btnEliminarLineaEscalafon.Location = new System.Drawing.Point(928, 33);
            this.btnEliminarLineaEscalafon.Name = "btnEliminarLineaEscalafon";
            this.btnEliminarLineaEscalafon.Size = new System.Drawing.Size(22, 23);
            this.btnEliminarLineaEscalafon.TabIndex = 2;
            this.btnEliminarLineaEscalafon.Text = "-";
            this.btnEliminarLineaEscalafon.UseVisualStyleBackColor = false;
            this.btnEliminarLineaEscalafon.Click += new System.EventHandler(this.btnEliminarLineaEscalafon_Click);
            // 
            // btnAgregarLineaEscalafon
            // 
            this.btnAgregarLineaEscalafon.BackColor = System.Drawing.Color.LightYellow;
            this.btnAgregarLineaEscalafon.Location = new System.Drawing.Point(928, 3);
            this.btnAgregarLineaEscalafon.Name = "btnAgregarLineaEscalafon";
            this.btnAgregarLineaEscalafon.Size = new System.Drawing.Size(22, 23);
            this.btnAgregarLineaEscalafon.TabIndex = 1;
            this.btnAgregarLineaEscalafon.Text = "+";
            this.btnAgregarLineaEscalafon.UseVisualStyleBackColor = false;
            this.btnAgregarLineaEscalafon.Click += new System.EventHandler(this.btnAgregarLineaEscalafon_Click);
            // 
            // dgEscalafon
            // 
            this.dgEscalafon.AllowUserToAddRows = false;
            this.dgEscalafon.AllowUserToDeleteRows = false;
            this.dgEscalafon.AllowUserToResizeColumns = false;
            this.dgEscalafon.AllowUserToResizeRows = false;
            this.dgEscalafon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgEscalafon.Location = new System.Drawing.Point(3, 3);
            this.dgEscalafon.Name = "dgEscalafon";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.Format = "t";
            dataGridViewCellStyle1.NullValue = "--------";
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgEscalafon.RowHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgEscalafon.RowHeadersVisible = false;
            this.dgEscalafon.RowTemplate.Height = 24;
            this.dgEscalafon.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgEscalafon.Size = new System.Drawing.Size(919, 297);
            this.dgEscalafon.TabIndex = 0;
            this.dgEscalafon.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgEscalafon_CellMouseClick);
            this.dgEscalafon.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgEscalafon_CellEndEdit);
            this.dgEscalafon.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgEscalafon_EditingControlShowing);
            this.dgEscalafon.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dgEscalafon_KeyDown);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(84, 43);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Horas Sobrantes";
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label4.Location = new System.Drawing.Point(67, 43);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(11, 13);
            this.label4.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(84, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Horas Faltantes";
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.label1.Location = new System.Drawing.Point(67, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(11, 13);
            this.label1.TabIndex = 5;
            // 
            // dgvHsPorCubrir
            // 
            this.dgvHsPorCubrir.AllowUserToAddRows = false;
            this.dgvHsPorCubrir.AllowUserToDeleteRows = false;
            this.dgvHsPorCubrir.AllowUserToResizeColumns = false;
            this.dgvHsPorCubrir.AllowUserToResizeRows = false;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.Format = "t";
            this.dgvHsPorCubrir.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvHsPorCubrir.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.NullValue = null;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvHsPorCubrir.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvHsPorCubrir.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHsPorCubrir.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.HsACubrirLunes,
            this.HsACubrirMartes,
            this.HsACubrirMiercoles,
            this.HsACubrirJueves,
            this.HsACubrirViernes,
            this.HsACubrirSabado,
            this.HsACubrirDomingo});
            this.dgvHsPorCubrir.Location = new System.Drawing.Point(176, 2);
            this.dgvHsPorCubrir.MultiSelect = false;
            this.dgvHsPorCubrir.Name = "dgvHsPorCubrir";
            this.dgvHsPorCubrir.ReadOnly = true;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle11.Format = "HH:MM";
            dataGridViewCellStyle11.NullValue = null;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvHsPorCubrir.RowHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.dgvHsPorCubrir.RowHeadersWidth = 115;
            this.dgvHsPorCubrir.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvHsPorCubrir.RowTemplate.Height = 24;
            this.dgvHsPorCubrir.Size = new System.Drawing.Size(645, 61);
            this.dgvHsPorCubrir.StandardTab = true;
            this.dgvHsPorCubrir.TabIndex = 1;
            this.dgvHsPorCubrir.RowHeadersWidthChanged += new System.EventHandler(this.dgvHsPorCubrir_RowHeadersWidthChanged);
            this.dgvHsPorCubrir.SelectionChanged += new System.EventHandler(this.dgvHsPorCubrir_SelectionChanged);
            // 
            // HsACubrirLunes
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.Format = "t";
            dataGridViewCellStyle4.NullValue = null;
            this.HsACubrirLunes.DefaultCellStyle = dataGridViewCellStyle4;
            this.HsACubrirLunes.HeaderText = "Lunes";
            this.HsACubrirLunes.Name = "HsACubrirLunes";
            this.HsACubrirLunes.ReadOnly = true;
            this.HsACubrirLunes.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.HsACubrirLunes.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.HsACubrirLunes.Width = 75;
            // 
            // HsACubrirMartes
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.Format = "t";
            this.HsACubrirMartes.DefaultCellStyle = dataGridViewCellStyle5;
            this.HsACubrirMartes.HeaderText = "Martes";
            this.HsACubrirMartes.Name = "HsACubrirMartes";
            this.HsACubrirMartes.ReadOnly = true;
            this.HsACubrirMartes.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.HsACubrirMartes.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.HsACubrirMartes.Width = 75;
            // 
            // HsACubrirMiercoles
            // 
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.Format = "t";
            this.HsACubrirMiercoles.DefaultCellStyle = dataGridViewCellStyle6;
            this.HsACubrirMiercoles.HeaderText = "Miercoles";
            this.HsACubrirMiercoles.Name = "HsACubrirMiercoles";
            this.HsACubrirMiercoles.ReadOnly = true;
            this.HsACubrirMiercoles.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.HsACubrirMiercoles.Width = 75;
            // 
            // HsACubrirJueves
            // 
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.Format = "t";
            this.HsACubrirJueves.DefaultCellStyle = dataGridViewCellStyle7;
            this.HsACubrirJueves.HeaderText = "Jueves";
            this.HsACubrirJueves.Name = "HsACubrirJueves";
            this.HsACubrirJueves.ReadOnly = true;
            this.HsACubrirJueves.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.HsACubrirJueves.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.HsACubrirJueves.Width = 75;
            // 
            // HsACubrirViernes
            // 
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.Format = "t";
            this.HsACubrirViernes.DefaultCellStyle = dataGridViewCellStyle8;
            this.HsACubrirViernes.HeaderText = "Viernes";
            this.HsACubrirViernes.Name = "HsACubrirViernes";
            this.HsACubrirViernes.ReadOnly = true;
            this.HsACubrirViernes.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.HsACubrirViernes.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.HsACubrirViernes.Width = 75;
            // 
            // HsACubrirSabado
            // 
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.Format = "t";
            dataGridViewCellStyle9.NullValue = null;
            this.HsACubrirSabado.DefaultCellStyle = dataGridViewCellStyle9;
            this.HsACubrirSabado.HeaderText = "Sabado";
            this.HsACubrirSabado.Name = "HsACubrirSabado";
            this.HsACubrirSabado.ReadOnly = true;
            this.HsACubrirSabado.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.HsACubrirSabado.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.HsACubrirSabado.Width = 75;
            // 
            // HsACubrirDomingo
            // 
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.Format = "t";
            this.HsACubrirDomingo.DefaultCellStyle = dataGridViewCellStyle10;
            this.HsACubrirDomingo.HeaderText = "Domingo";
            this.HsACubrirDomingo.Name = "HsACubrirDomingo";
            this.HsACubrirDomingo.ReadOnly = true;
            this.HsACubrirDomingo.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.HsACubrirDomingo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.HsACubrirDomingo.Width = 75;
            // 
            // EscalafonCMS
            // 
            this.EscalafonCMS.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copiarToolStripMenuItem,
            this.pegarToolStripMenuItem,
            this.toolStripSeparator1,
            this.marcarToolStripMenuItem});
            this.EscalafonCMS.Name = "EscalafonCMS";
            this.EscalafonCMS.Size = new System.Drawing.Size(119, 76);
            // 
            // copiarToolStripMenuItem
            // 
            this.copiarToolStripMenuItem.Name = "copiarToolStripMenuItem";
            this.copiarToolStripMenuItem.Size = new System.Drawing.Size(118, 22);
            this.copiarToolStripMenuItem.Text = "Copiar";
            this.copiarToolStripMenuItem.Click += new System.EventHandler(this.copiarToolStripMenuItem_Click);
            // 
            // pegarToolStripMenuItem
            // 
            this.pegarToolStripMenuItem.Name = "pegarToolStripMenuItem";
            this.pegarToolStripMenuItem.Size = new System.Drawing.Size(118, 22);
            this.pegarToolStripMenuItem.Text = "Pegar";
            this.pegarToolStripMenuItem.Click += new System.EventHandler(this.pegarToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(115, 6);
            // 
            // marcarToolStripMenuItem
            // 
            this.marcarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.enOtroServicioToolStripMenuItem,
            this.descansoToolStripMenuItem,
            this.licenciaToolStripMenuItem});
            this.marcarToolStripMenuItem.Name = "marcarToolStripMenuItem";
            this.marcarToolStripMenuItem.Size = new System.Drawing.Size(118, 22);
            this.marcarToolStripMenuItem.Text = "Marcar";
            // 
            // enOtroServicioToolStripMenuItem
            // 
            this.enOtroServicioToolStripMenuItem.Name = "enOtroServicioToolStripMenuItem";
            this.enOtroServicioToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.enOtroServicioToolStripMenuItem.Text = "En Otro Servicio";
            this.enOtroServicioToolStripMenuItem.Click += new System.EventHandler(this.enOtroServicioToolStripMenuItem_Click);
            // 
            // descansoToolStripMenuItem
            // 
            this.descansoToolStripMenuItem.Name = "descansoToolStripMenuItem";
            this.descansoToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.descansoToolStripMenuItem.Text = "Descanso";
            this.descansoToolStripMenuItem.Click += new System.EventHandler(this.descansoToolStripMenuItem_Click);
            // 
            // licenciaToolStripMenuItem
            // 
            this.licenciaToolStripMenuItem.Name = "licenciaToolStripMenuItem";
            this.licenciaToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.licenciaToolStripMenuItem.Text = "Licencia";
            this.licenciaToolStripMenuItem.Click += new System.EventHandler(this.licenciaToolStripMenuItem_Click);
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.Format = "t";
            dataGridViewCellStyle12.NullValue = null;
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle12;
            this.dataGridViewTextBoxColumn1.HeaderText = "Hs Por Cubrir";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn1.Width = 75;
            // 
            // dataGridViewTextBoxColumn2
            // 
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle13.Format = "t";
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridViewTextBoxColumn2.HeaderText = "Hs Por Cubrir ";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn2.Width = 75;
            // 
            // dataGridViewTextBoxColumn3
            // 
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle14.Format = "t";
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle14;
            this.dataGridViewTextBoxColumn3.HeaderText = "Hs Por Cubrir";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn3.Width = 75;
            // 
            // dataGridViewTextBoxColumn4
            // 
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle15.Format = "t";
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle15;
            this.dataGridViewTextBoxColumn4.HeaderText = "Hs Por Cubrir";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn4.Width = 75;
            // 
            // dataGridViewTextBoxColumn5
            // 
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle16.Format = "t";
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle16;
            this.dataGridViewTextBoxColumn5.HeaderText = "Hs Por Cubrir";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn5.Width = 75;
            // 
            // dataGridViewTextBoxColumn6
            // 
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle17.Format = "t";
            dataGridViewCellStyle17.NullValue = null;
            this.dataGridViewTextBoxColumn6.DefaultCellStyle = dataGridViewCellStyle17;
            this.dataGridViewTextBoxColumn6.HeaderText = "Hs Por Cubrir";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn6.Width = 75;
            // 
            // dataGridViewTextBoxColumn7
            // 
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle18.Format = "t";
            this.dataGridViewTextBoxColumn7.DefaultCellStyle = dataGridViewCellStyle18;
            this.dataGridViewTextBoxColumn7.HeaderText = "Hs Por Cubrir";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn7.Width = 75;
            // 
            // EscalafonForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(959, 484);
            this.Controls.Add(this.splitContainer1);
            this.Name = "EscalafonForm";
            this.Text = "Escalafon";
            this.Load += new System.EventHandler(this.Escalafon_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Escalafon_FormClosed);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.EscalafonForm_FormClosing);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.GraficosPL.ResumeLayout(false);
            this.GraficosPL.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.Panel2.PerformLayout();
            this.splitContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgEscalafon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHsPorCubrir)).EndInit();
            this.EscalafonCMS.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DataGridTAB dgEscalafon;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.DataGridView dgvHsPorCubrir;
        private TextBoxKeyDown textBoxKeyDown1;
        private MaskedTextBoxKeyDown maskedTextBoxKeyDown1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.Button btnEliminarLineaEscalafon;
        private System.Windows.Forms.Button btnAgregarLineaEscalafon;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.MaskedTextBox mtServicio;
        private System.Windows.Forms.MaskedTextBox mtCliente;
        private System.Windows.Forms.TextBox txtServicio;
        private System.Windows.Forms.TextBox txtCliente;
        private System.Windows.Forms.ToolStripButton btnBuscarClientes;
        private System.Windows.Forms.Button PosteriorBTN;
        private System.Windows.Forms.Button AnteriorBTN;
        private System.Windows.Forms.ContextMenuStrip EscalafonCMS;
        private System.Windows.Forms.ToolStripMenuItem copiarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pegarToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem marcarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem descansoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem licenciaToolStripMenuItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn HsACubrirLunes;
        private System.Windows.Forms.DataGridViewTextBoxColumn HsACubrirMartes;
        private System.Windows.Forms.DataGridViewTextBoxColumn HsACubrirMiercoles;
        private System.Windows.Forms.DataGridViewTextBoxColumn HsACubrirJueves;
        private System.Windows.Forms.DataGridViewTextBoxColumn HsACubrirViernes;
        private System.Windows.Forms.DataGridViewTextBoxColumn HsACubrirSabado;
        private System.Windows.Forms.DataGridViewTextBoxColumn HsACubrirDomingo;
        private System.Windows.Forms.ToolStripButton GuardarBTN;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem enOtroServicioToolStripMenuItem;
        private System.Windows.Forms.TextBox cubiertoTB;
        private System.Windows.Forms.Button VerContratoBTN;
        private System.Windows.Forms.Label CubiertoLBL;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label ConLBL;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel GraficosPL;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton btnVerEscalafonFuncionario;
        private System.Windows.Forms.ToolStripButton btnCancelar;
    }
}